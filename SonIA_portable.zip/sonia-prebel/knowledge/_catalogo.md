# Catálogo de la base de conocimiento de SonIA

Índice para ubicar rápidamente la sección correcta. No es fuente de respuesta: la respuesta
siempre se toma del archivo indicado.

## Versiones vigentes

| Archivo | Versión | Origen |
|---|---|---|
| 01_vinculacion_y_nomina.md | 2026-03-10 | Vinculación_y_nomina_20260310.md |
| 02_creditos.md | 2026-03-10 | Creditos_Prebel_20260310.md |
| 03_auxilios_y_beneficios.md | 2026-03-10 | Auxilios_y_beneficios_Prebel_20260310.md |
| 04_glosario_business_partner.md | 2026-09-22 | Glosario_Business_Partner_20260922.md |

## Tema → archivo → sección

| Tema / palabras clave | Archivo | Sección | ¿Depende del público? |
|---|---|---|---|
| Certificado laboral | 01 | 1 | Sí |
| Cesantías (vivienda, reforma, predial, hipoteca, notariales, estudio) | 01 | 2.1–2.6 | No |
| Inclusión beneficiarios EPS / EPS Sura | 01 | 3 | Sí (si no es Sura) |
| Caja de compensación / Comfama | 01 | 4 | Sí |
| Traslado de EPS | 01 | 5 | Sí |
| Traslado a Colpensiones / pensión | 01 | 6 | Sí (envío de soporte) |
| Días de vacaciones | 01 | 7 | Sí |
| Envío de incapacidades | 01 | 8 (y 03 §2) | Sí |
| Comprobante seguridad social | 01 | 9 | No |
| Actualización de datos | 01 | 11 | No |
| Crédito educación / computador | 02 | 1 | No |
| Crédito calamidad mascotas | 02 | 2 | No |
| Crédito casos especiales de salud | 02 | 3 | No |
| Crédito vivienda (compra, reforma, calamidad habitacional, legalización, gravámenes, predial) | 02 | 4 | No |
| Antigüedad para créditos / contacto créditos | 02 | 5 | No |
| Auxilio educativo / bono de desarrollo | 03 | 1 | No |
| Auxilio de incapacidad | 03 | 2 | Sí (canal de reporte) |
| EMI emergencias | 03 | 3 | No |
| Seguro de vida | 03 | 4 | No |
| Auxilio visual / odontológico | 03 | 5 | No |
| Alimentación en sede | 03 | 6 | No |
| Alimentación impulso y mercadeo | 03 | 7 | No |
| Desahogadero / Red de amor | 03 | 8 | No |
| Auxilio de salud mental | 03 | 9 | No |
| Brigadistas / emisores de seguridad | 03 | 10 | No |
| Nacimiento / adopción / aborto | 03 | 11 | No |
| Matrimonio | 03 | 12 | No |
| Pensión de vejez o invalidez (auxilio) | 03 | 13 | No |
| Muerte o invalidez del colaborador | 03 | 14 | No |
| Muerte de familiares | 03 | 15 | No |
| Contactos de auxilios y beneficios | 03 | 16 | Sí |
| Business Partner (Nathalia León, Laura Jaramillo) | 04 | Business Partner | No (depende de sede) |
| Accidente / incidente de trabajo | 04 | Accidente / Incidente | No |
| Licencias (remunerada, no remunerada, maternidad, paternidad, luto), suspensión | 04 | Ausentismo | No |
| Onboarding, proceso disciplinario, concertación, grupos primarios, pacto colectivo, GPS, guion de líderes | 04 | Término respectivo | No |

## Directorio de contactos (tal como aparece en el corpus)

| Persona | Rol / público | Contacto | Archivo |
|---|---|---|---|
| Stefanny Pulgarín Correa | Analista de Bienestar y RSE (créditos, auxilios, beneficios) | 3104057760 · stefanny.pulgarin@prebel.com.co | 02, 03 |
| Michell Román | Asistente Gestión Humana · personal administrativo e impulso y mercado | 3147710112 · michell.roman@prebel.com.co | 01 |
| Angela Quintero | Personal operativo | 3234830720 · Angela.quintero@prebel.com.co | 01 |
| Lucía Mejía | Cesantías; nómina impulso y mercadeo; practicantes | lucia.mejias@prebel.com.co · WhatsApp 3104589490 | 01, 03 |
| Shirley Silgado | Nómina administrativa | Shirley.silgado@prebel.com.co | 01, 03 |
| Yasmín Yepes | Nómina operativa | Yasmin.yepes@prebel.com.co | 01, 03 |
| Linda Salamanca | Vacaciones impulso y mercado | 3102150234 · linda.salamanca@prebel.com.co | 01 |
| Nathalia León | Business Partner · Sede Productora y Sede Rionegro | — | 04 |
| Laura Jaramillo | Business Partner · Sede Comercial y fuera de sede | — | 04 |
| Incapacidades (operativo) | Buzón | incapacidades@prebel.com.co | 01, 03 |
