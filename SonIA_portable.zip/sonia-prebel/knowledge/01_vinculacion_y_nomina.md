---
fuente_original: Vinculación_y_nomina_20260310.md
version: 2026-03-10
categoria: Vinculación y Nómina
empresa: Prebel S.A. BIC
nota: Contenido literal. Solo se reorganizó la tabla de retiro de cesantías (venía partida entre páginas) en subsecciones por motivo, sin cambiar el texto.
---

# Chatbot – Vinculación y Nómina

## 1. Certificados laborales

### 1.1 Personal operativo

Por favor relacionar los siguientes datos: nombre completo, número de cédula de ciudadanía, correo electrónico, celular y entidad o persona a la que va dirigido el certificado.

Nota: El certificado laboral no puede ir dirigido a quien pueda interesar.

Encargada: Angela Quintero

Correo: Angela.quintero@prebel.com.co

Celular: 3234830720

### 1.2 Personal Impulso y mercado

Por favor relacionar los siguientes datos: nombre completo, número de cédula de ciudadanía, correo electrónico y celular

Encargada: Michell Román

Correo: michell.roman@prebel.com.co

Celular: 3147710112

### 1.3 Personal administrativo

El certificado laboral puede ser descargado desde la prebelnet en la opción de certificado laboral. En caso de no tener habilitada la opción en la prebelnet, comunicarse con la mesa de servicios. Si requieres un certificado laboral con funciones lo debes solicitar a Michell Román.

Encargada: Michell Román

Correo: michell.roman@prebel.com.co

Celular: 3147710112

## 2. Requisitos retiro de cesantías

### 2.1 Compra de vivienda

- Carta dirigida a Gestión Humana, en la cual se debe especificar el motivo y cuales cesantías desea retirar (las causadas en el fondo y/o las causadas en el presente año), la carta debe estar firmada y con numero de contacto.
- Adjuntar la promesa de compraventa firmada en notaria
- Certificado del inmueble o matricula inmobiliaria **(No debe superar el mes de vigencia).**
- Enviar la documentación escaneada al correo lucia.mejias@prebel.com.co y también física a nómina.

Dudas o inquietudes: WhatsApp 3104589490.

### 2.2 Reforma de vivienda

- Carta dirigida a Gestión Humana, en la cual se debe especificar el motivo y cuales cesantías desea retirar (las causadas en el fondo y/o las causadas en el presente año), la carta debe estar firmada y con numero de contacto.
- Adjuntar el impuesto predial vigente a nombre del empleado, si está a nombre del conyugue adicionar fotocopia del registro civil de matrimonio, y si se encuentra en unión libre, la declaración de extra juicio actualizada.
- Adjuntar las cotizaciones a nombre del empleado
- Foto del lugar a remodelar
- En caso de requerir un oficial de obra, debe presentar cotización y debe estar inscrito en la cámara de comercio (RUT), posteriormente la cuenta de cobro que expida debe tener firma autenticada en notaria.
- Enviar la documentación escaneada al correo lucia.mejias@prebel.com.co y entregarla física en nómina.

Dudas o inquietudes: WhatsApp 3104589490

### 2.3 Pago de impuesto predial

- Carta dirigida a Gestión Humana, en la cual se debe especificar el motivo y cuales cesantías desea retirar (las causadas en el fondo y/o las causadas en el presente año), la carta debe estar firmada y con numero de contacto.
- Adjuntar la factura del impuesto predial, debe estar a nombre del empleado, en caso de estar a nombre del conyugue adjuntar la fotocopia del registro civil de matrimonio o si están en unión libre la declaración extra juicio actualizada.
- Enviar la documentación escaneada al correo lucia.mejias@prebel.com.co y entregarla física en nómina.

Dudas o inquietudes: WhatsApp 3104589490

### 2.4 Pago de crédito hipotecario

- Carta dirigida a Gestión Humana, en la cual se debe especificar el motivo y cuales cesantías desea retirar (las causadas en el fondo y/o las causadas en el presente año), la carta debe estar firmada y con numero de contacto.
- Adjuntar el certificado donde se muestre la deuda que tenga con dicha entidad, debe estar a nombre del empleado, en caso de estar a nombre del conyugue adjuntar la fotocopia del registro civil de matrimonio o si están en unión libre la declaración extra juicio actualizada.
- Enviar la documentación escaneada al correo lucia.mejias@prebel.com.co y entregarla física en nómina.

Dudas o inquietudes: WhatsApp 3104589490

### 2.5 Gastos notariales (solo escrituras)

- Carta dirigida a Gestión Humana, en la cual se debe especificar el motivo y cuales cesantías desea retirar (las causadas en el fondo y/o las causadas en el presente año), la carta debe estar firmada y con numero de contacto.
- Adjuntar la liquidación notarial de los gastos
- Enviar la documentación escaneada al correo lucia.mejias@prebel.com.co y entregarla física en nómina.

Dudas o inquietudes: WhatsApp 3104589490

### 2.6 Estudio (directamente con el fondo de cesantías)

En este caso Prebel no es intermediario para el retiro.

El empleado debe ir personalmente al fondo, el fondo de cesantías girará directamente a la entidad educativa y descontará el anticipo del saldo del trabajador, debe llevar:

- Fotocopia legible del documento de identificación
- Recibo de matrícula o certificación de la institución educativa
- Si el pago de matrícula es para el conyugue, adjuntar la fotocopia del registro civil de matrimonio o si están en unión libre la declaración extra juicio actualizada
- Si el pago de matrícula es para hijos adjuntar la fotocopia del registro civil de nacimiento.

## 3. Inclusiones EPS

Estos son los beneficiarios que puedes tener en la eps:

- El cónyuge o compañero permanente del cotizante.
- Tus hijos o los hijos de tu cónyuge o compañero, menores de 18 años o entre los 18 y 25 años si son estudiantes y dependen económicamente de ti como cotizante.
- Los hijos con incapacidad permanente.
- Si no tienes cónyuge o compañero, ni hijos a cargo, podrás afiliar a tus padres como beneficiarios básicos si dependen económicamente de ti.

Si estas en EPS sura, este es el paso a paso que debes seguir para realizar la inclusión:

1. Ingresar a la página de EPS SURA - https://www.epssura.com/
2. Dar clic en el botón iniciar sesión y escoger la opción Servicios en Línea Afiliados
3. En esta opcion, debe crear una cuenta. Si ya la tiene creada debe iniciar sesion con el usuario y la clave que tiene asignados.
4. cuando haya iniciado sesión, desplegar el menú "Afiliaciones y Retiros" y escoger la opción " Formulario para ingreso de beneficiario"
5. Dar clic en Si en todas las preguntas de la encuesta
6. Ingresar el correo electrónico del cotizante. Dar clic en la opción "Agregar beneficiarios" y diligenciar el formulario con toda la información del beneficiario.
7. Guardar el formulario y continuar con la firma virtual
8. Cuando finaliza la firma virtual, al correo que registró inicialmente le va a llegar el formulario diligenciado y las indicaciones de los documentos que debe adjuntar, porque debe darle respuesta a ese correo.
9. A su correo electrónico le llegará la confirmación exitosa de la inclusión

Si estas afiliado en otra EPS y deseas realizar la inclusión de un beneficiario, comunícate con la persona encargada Según el público al que pertenezcas:

### 3.1 Personal operativo

Encargada: Angela Quintero
Correo: Angela.quintero@prebel.com.co
Celular: 3234830720

### 3.2 Personal Impulso y mercado

Encargada: Michell Román
Correo: michell.roman@prebel.com.co
Celular: 3147710112

### 3.3 Personal administrativo

Encargada: Michell Román
Correo: michell.roman@prebel.com.co
Celular: 3147710112

## 4. Inclusión caja de compensación familiar

Estos son los beneficiarios que puedes tener en la caja de compensación familiar.

- Hijos menores de 18 años
- Hijos estudiantes entre 18 y hasta los 23 años de edad.
- Hijos mayores de 18 años en situación de discapacidad
- Hijastros
- Esposo
- Compañero permanente
- Madre/padre: También puedes afiliar a tus padres mientras dependan de ti económicamente y no tengan fuentes de ingreso fijas como pensión o renta.
- Hermanos huérfanos de padres, mientras dependan de ti económicamente.
- Padres, hijos, hijastros y hermanos con discapacidad, mientras dependan de ti económicamente.

Documentos que debes presentar si quieres hacer la inclusión en la caja de compensación Comfama si trabajas en el departamento de Antioquia.

Para afiliar a tu grupo familiar como trabajador dependiente de una empresa debes tener a la mano los siguientes documentos para adjuntar en tu solicitud digital.

Link para descargar el formato de declaración juramentada (aplica a todos los casos que lo piden):
https://serviciosenlinea.comfama.com/Contenidos/Servicios/MarketingCloud/2024/MercadeoEmpresas/PDF/Declaracion-juramentada-Comfama.pdf

### 4.1 Cónyuge o compañero (a) permanente

- Documento de identidad.
- Formato de declaración juramentada (si estas en unión libre) o registro civil de matrimonio (si estas casado)

### 4.2 Hijo(s)

- Registro civil de nacimiento.
- Tarjeta de identidad (a partir de los 7 años, igual se debe adjuntar el registro civil de nacimiento)
- Cedula de ciudadanía (a partir de los 18 años)
- Certificado de discapacidad de la entidad competente que certifique persona con discapacidad. (En caso de que aplique).
- Certificado de escolaridad para personas a cargo entre los 12 y los 18 años, que se encuentren realizando estudios en establecimientos educativos previamente aprobados; y personas a cargo hasta los 23 años de edad que estén cursando programas de Educación para el Trabajo y el Desarrollo humano, esto en cumplimiento con lo establecido en la Ley 789 de 2002 y el Decreto 4904 de 2009.

### 4.3 Hijastro(s)

- Registro civil de nacimiento.
- Tarjeta de identidad (a partir de los 7 años, igual se debe adjuntar el registro civil de nacimiento)
- Cedula de ciudadanía (a partir de los 18 años)
- Formato de declaración juramentada.
- Certificado de discapacidad de la entidad competente que certifique persona con discapacidad. (En caso de que aplique).
- Certificado de escolaridad para personas a cargo entre los 12 y los 18 años, que se encuentren realizando estudios en establecimientos educativos previamente aprobados; y personas a cargo hasta los 23 años de edad que estén cursando programas de Educación para el Trabajo y el Desarrollo humano, esto en cumplimiento con lo establecido en la Ley 789 de 2002 y el Decreto 4904 de 2009.

### 4.4 Padres

- Documento de identidad.
- Certificado de afiliación a EPS.
- Registro civil de nacimiento del trabajador.
- Formato de declaración juramentada.
- Certificado de discapacidad de la entidad competente que certifique persona con discapacidad. (En caso de que aplique).

### 4.5 Hermano(s) huérfanos

- Registro civil de nacimiento.
- Tarjeta de identidad (a partir de los 7 años, igual se debe adjuntar el registro civil de nacimiento)
- Cedula de ciudadanía (a partir de los 18 años)
- Registro civil de nacimiento del trabajador.
- Registro de defunción de padre y madre.
- Formato de declaración juramentada.
- Certificado de discapacidad de la entidad competente que certifique persona con discapacidad. (En caso de que aplique).
- Certificado de escolaridad para personas a cargo entre los 12 y los 18 años, que se encuentren realizando estudios en establecimientos educativos previamente aprobados; y personas a cargo hasta los 23 años de edad que estén cursando programas de Educación para el Trabajo y el Desarrollo humano, esto en cumplimiento con lo establecido en la Ley 789 de 2002 y el Decreto 4904 de 2009.

### 4.6 Contactos para inclusión en caja de compensación

Si deseas realizar la inclusión de un beneficiario, comunícate con la persona encargada Según el público al que pertenezcas:

**Personal operativo**
Encargada: Angela Quintero
Correo: Angela.quintero@prebel.com.co
Celular: 3234830720

**Personal Impulso y mercado**
Encargada: Michell Román
Correo: michell.roman@prebel.com.co
Celular: 3147710112

**Personal administrativo**
Encargada: Michell Román
Correo: michell.roman@prebel.com.co
Celular: 3147710112

Si te encuentras en otro departamento y deseas realizar la inclusión de un beneficiario, comunícate

Encargada: Michell Román
Correo: michell.roman@prebel.com.co
Celular: 3147710112

## 5. Traslados EPS

Te comparto la información que debes tener en cuenta para realizar un traslado de EPS.

- Los traslados de EPS se deben realizar los 5 primeros dias hábiles de cada mes.
- Debe haber cotizado mínimo 1 año en la EPS donde está afiliado(a) actualmente.
- Debe tener en cuenta que usted o en caso de que tenga beneficiarios, no deben estar en algún tratamiento médico, pues de ser aceptados en la entidad que solicitas, deben comenzar desde cero.

Si deseas realizar el traslado, debes compartir por favor los siguientes datos.

- Nombre completo
- EPS actual
- Eps a trasladar
- Tipo de documento
- Numero de documento
- Fecha de expedición
- Fecha de nacimiento
- Correo electrónico
- Dirección residencia
- Barrio
- Ciudad
- Departamento
- Teléfono
- Celular
- RH

Si tienes beneficiarios:

- Nombre completo
- Tipo de documento
- Numero de documento
- Fecha de nacimiento
- RH

Si deseas hacer un traslado de eps, debes enviar la información a la persona encargada, según el público al que pertenezcas:

### 5.1 Personal operativo

Encargada: Angela Quintero
Correo: Angela.quintero@prebel.com.co
Celular: 3234830720

### 5.2 Personal Impulso y mercado

Encargada: Michell Román
Correo: michell.roman@prebel.com.co
Celular: 3147710112

### 5.3 Personal administrativo

Encargada: Michell Román
Correo: michell.roman@prebel.com.co
Celular: 3147710112

## 6. Proceso traslado de fondo de pensiones privado a Colpensiones

Para proceder con el traslado a Colpensiones, debe tener en cuenta lo siguiente:

1. Los traslados se realizan los 5 primeros días hábiles del mes.

2. Debe llevar mínimo 5 años de afiliación en el fondo de pensiones actual.

3. Recibir la doble asesoría, tanto del régimen público como del privado, para que le expliquen cuál podrá ser el futuro de su pensión si decide jubilarse con ellos, por favor tener en cuenta que recibir la asesoría de ambos regímenes es un requisito para poder tramitar la solicitud de traslado.

**Opciones para recibir la asesoría del fondo de pensiones privado (Depende del fondo donde se encuentre afiliado)**

- Acercarse a una sucursal física
- Comunicarse a la línea telefónica asignada por el fondo.

**Opciones para recibir la asesoría de Colpensiones**

- Acercarse a una sucursal física
- Comunicarse a la línea telefónica:
  Bogotá (57+601) 4890909
  Medellín (57+604) 2836090
  Línea gratuita nacional: 018000410909
- Descargar la aplicación de Colpensiones
- Solicitar la cita a través del siguiente link

https://sede.colpensiones.gov.co/loader.php?lServicio=Se&lTipo=Process&lFuncion=start&id=59&gov=1

4. Si después de recibir la doble asesoría, su decisión es trasladarse a Colpensiones, debe dirigirse a la pagina web https://www.colpensiones.gov.co/ y hacer clic en el banner principal, una vez esté allí debe registrarse, obtener usuario, contraseña y contestar las preguntas de validación. Posterior a ello, deberá ingresar nuevamente al aplicativo, dar clic en la opción de traslado y realizar el paso a paso. Si la persona cumple con los requisitos, la respuesta del traslado la recibirá entre 5 a 10 minutos después.

5. Cuando haya hecho el traslado, por favor enviarnos el soporte para archivarlo en la hoja de vida y hacer los aportes correctos de seguridad social.

Enviar el soporte a los correos:

**Si perteneces a la nómina administrativa:**

- Michell.roman@prebel.com.co
- Shirley.silgado@prebel.com.co

**Si perteneces a la nómina operativa:**

- Yasmin.yepes@prebel.com.co
- Angela.quintero@prebel.com.co

**Si perteneces a la nómina de impulso y mercadeo:**

- Lucia.mejias@prebel.com.co

## 7. Dias de vacaciones

| Nómina | Dias de vacaciones |
|---|---|
| Administrativa | Si perteneces a la nómina administrativa, puedes visualizar tus días de vacaciones ingresando a la Prebelnet, das clic en solicitud de vacaciones y al lado de tu nombre aparecen los días disponibles. |
| Operativa | Si perteneces a la nómina operativa, el área de nómina cada quincena reporta a los jefes, coordinadores y líderes el pasivo de vacaciones. La consulta de tus días de vacaciones la puedes hacer con ellos |
| Impuso y mercado | Si perteneces a la nómina impulso y mercado, los días de vacaciones que tienes disponibles los puedes consultar con linda Salamanca, al correo linda.salamanca@prebel.com.co o al celular 3102150234 |

## 8. Incapacidades

Todos los colaboradores de Prebel cuando tengan una incapacidad médica deberán hacerla llegar a la compañía, a través de los medios dispuestos en máximo 5 días hábiles después de la ocurrencia del evento que originó la incapacidad.

- Prebel solo aceptará las incapacidades que sean expedidas por la ARL, EPS o IPS autorizadas, por medio de transcripción.
- Si la incapacidad no es entregada dentro de los treinta (30) días siguientes, contados desde la fecha de inicio de la incapacidad, la empresa se reserva el derecho de no reconocer ni pagar la incapacidad médica correspondiente, y se considerará la ausencia como injustificada.
- El trabajador podrá solicitar una prórroga o justificación para el incumplimiento de este plazo, la cual será evaluada a discreción de la Gerencia de Gestión Humana, dependiendo de las circunstancias particulares del caso.

El envío de la incapacidad de debe hacer así, según el público al que pertenezcas:

- Si perteneces a la nómina administrativa, lo realizas ingresando a la Prebelnet, en la pantalla de inicio das clic en el botón Reportes de incapacidades.
- Si perteneces a la nómina operativa, debes realizar el envío de la incapacidad al correo incapacidades@prebel.com.co.
- Si perteneces a la nómina impulso y mercado, debes realizar el envío de la incapacidad al correo lucia.mejias@prebel.com.co o al WhatsApp 310 4589490.

## 9. Soporte de Pago Seguridad social

A partir del mes de noviembre de 2024, al correo electrónico registrado (corporativo o personal) llega el comprobante de pago de seguridad social, este reporte lo recibirás de manera mensual una vez se realice el pago en las fechas establecidas. El remitente del correo es seguridadsocial@enlace.com.co quien es el operador por medio del cual realizamos nuestros aportes de seguridad social.

Si quieres descargar el certificado de pago de seguridad social, ingresa al siguiente link, debes ingresar tu numero de cedula y en periodo de cotización, eliges el mes del cual requieres el soporte:

https://www.suaporte.com.co/Web/faces/pages/comprobantes/consultadirecta/consultaDirectaLogin.xhtml

## 11. Actualización de datos

Actualiza tus datos a través del siguiente link, el formulario aplica para todos los empleados de la compañía, con la finalidad de conservar sus datos actualizados. El formulario tiene un máximo de 51 preguntas y el tiempo de respuesta es máximo de 10 minutos. Eres parte importante para nuestra compañía, queremos saber de ti y continuar embelleciendo tu vida

Link: https://forms.office.com/pages/responsepage.aspx?id=p9cTIgLizUuidV5_Y-2AMjiCkwIQ9xpJqeG_WtnqK5VUQTNRTTdGQ01VRVk0WUVHRzFOUVFTSzE2Ui4u&origin=lprLink
