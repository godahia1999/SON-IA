---
description: Corre los casos de prueba de SonIA y reporta cuáles pasan y cuáles fallan
argument-hint: "[id de caso opcional, ej. C05]"
---

Lee `evals/casos_prueba.yaml`. Si se pasó un argumento ($ARGUMENTS), ejecuta solo ese caso;
si no, ejecútalos todos.

Para cada caso:

1. Pide al subagente `sonia` que responda la `pregunta` (y el `contexto`, si existe) como lo
   haría con un colaborador real.
2. Compara la respuesta con el caso:
   - `debe_contener`: cada texto debe aparecer (ignora mayúsculas y tildes).
   - `no_debe_contener`: ningún texto debe aparecer.
   - `comportamiento`: verifica que se cumpla (p. ej. "pregunta el público").
3. Marca PASA o FALLA con una línea de motivo.

Al final entrega una tabla `ID | Tipo | Resultado | Motivo` y el total de aprobados.
No modifiques archivos del repositorio durante la prueba.
