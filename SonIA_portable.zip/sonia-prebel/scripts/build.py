#!/usr/bin/env python3
"""Genera los entregables portables de SonIA en dist/.

Uso:  python scripts/build.py

Produce:
  dist/sonia_prompt_completo.md   -> prompt + corpus en un solo archivo (para plataformas
                                     que solo aceptan un bloque de instrucciones)
  dist/skill/sonia-gestion-humana/ -> skill autocontenida (SKILL.md + references/)
  dist/sonia-gestion-humana.zip    -> la misma skill, lista para subir a Claude.ai
  dist/gpt_instrucciones.md        -> instrucciones cortas para un GPT de ChatGPT
                                     (los .md de knowledge/ se suben como archivos)
"""
from pathlib import Path
import shutil
import zipfile

RAIZ = Path(__file__).resolve().parent.parent
PROMPT = RAIZ / "prompts" / "system_prompt.md"
KNOW = RAIZ / "knowledge"
SKILL_SRC = RAIZ / ".claude" / "skills" / "sonia-gestion-humana" / "SKILL.md"
DIST = RAIZ / "dist"


def archivos_conocimiento():
    return sorted(p for p in KNOW.glob("*.md") if not p.name.startswith("_"))


def prompt_completo():
    partes = [PROMPT.read_text(encoding="utf-8"), "\n\n---\n\n# BASE DE CONOCIMIENTO\n"]
    for p in [KNOW / "_catalogo.md", *archivos_conocimiento()]:
        partes.append(f"\n\n<documento nombre=\"{p.name}\">\n\n")
        partes.append(p.read_text(encoding="utf-8").strip())
        partes.append("\n\n</documento>")
    salida = DIST / "sonia_prompt_completo.md"
    salida.write_text("".join(partes), encoding="utf-8")
    return salida


def skill():
    destino = DIST / "skill" / "sonia-gestion-humana"
    if destino.exists():
        shutil.rmtree(destino)
    refs = destino / "references"
    refs.mkdir(parents=True)
    # SKILL.md sin la nota de repositorio (no aplica dentro de la skill empaquetada)
    texto = SKILL_SRC.read_text(encoding="utf-8").split("\n> En el repositorio")[0].rstrip() + "\n"
    (destino / "SKILL.md").write_text(texto, encoding="utf-8")
    shutil.copy(PROMPT, refs / "system_prompt.md")
    for p in [KNOW / "_catalogo.md", *archivos_conocimiento()]:
        shutil.copy(p, refs / p.name)
    zip_path = DIST / "sonia-gestion-humana.zip"
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as z:
        for f in sorted(destino.rglob("*")):
            if f.is_file():
                z.write(f, f.relative_to(destino.parent))
    return destino, zip_path


def gpt():
    texto = (
        "Eres SonIA, asistente de Gestión Humana de Prebel S.A. BIC.\n"
        "Sigue AL PIE DE LA LETRA el archivo de conocimiento 'system_prompt.md' "
        "(tono, reglas, mensajes fijos y ejemplos).\n"
        "Responde ÚNICAMENTE con los archivos 01_vinculacion_y_nomina.md, 02_creditos.md, "
        "03_auxilios_y_beneficios.md y 04_glosario_business_partner.md. Usa _catalogo.md para ubicar la sección.\n"
        "Sin navegación web. Si no está en los archivos responde: \"Lo siento, esa información no está "
        "disponible en este momento, ya que mi conocimiento se limita únicamente a los documentos cargados.\"\n"
        "Idioma: español.\n"
    )
    salida = DIST / "gpt_instrucciones.md"
    salida.write_text(texto, encoding="utf-8")
    return salida


if __name__ == "__main__":
    DIST.mkdir(exist_ok=True)
    p = prompt_completo()
    d, z = skill()
    g = gpt()
    print(f"OK  {p.relative_to(RAIZ)}  ({p.stat().st_size/1024:.1f} KB, ~{p.stat().st_size//4:,} tokens)")
    print(f"OK  {d.relative_to(RAIZ)}/")
    print(f"OK  {z.relative_to(RAIZ)}")
    print(f"OK  {g.relative_to(RAIZ)}")
