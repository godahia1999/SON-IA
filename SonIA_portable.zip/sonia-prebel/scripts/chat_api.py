#!/usr/bin/env python3
"""Chat de consola con SonIA usando la API de Claude.

Es la base para conectar WhatsApp: la función `responder(historial, mensaje)` es la que
llamaría el webhook de Meta WhatsApp Cloud API.

Requisitos:
  pip install anthropic
  export ANTHROPIC_API_KEY="..."        # nunca la guardes en el repositorio
  export SONIA_MODELO="claude-sonnet-5-5"   # opcional (o claude-haiku-5-5 para menor costo)
  export SONIA_CANAL="whatsapp"             # opcional: ajusta formato a texto plano

Uso:
  python scripts/chat_api.py
"""
import os
from pathlib import Path

import anthropic

RAIZ = Path(__file__).resolve().parent.parent
MODELO = os.environ.get("SONIA_MODELO", "claude-sonnet-5-5")
CANAL = os.environ.get("SONIA_CANAL", "web")


def cargar_sistema():
    """Prompt + corpus completo. Se marca para caché: solo se cobra completo la primera vez."""
    prompt = (RAIZ / "prompts" / "system_prompt.md").read_text(encoding="utf-8")
    docs = []
    for p in sorted((RAIZ / "knowledge").glob("*.md")):
        docs.append(f'<documento nombre="{p.name}">\n{p.read_text(encoding="utf-8")}\n</documento>')
    canal = (
        "\n\nCANAL ACTUAL: WhatsApp. No uses tablas; usa listas y *negrita* de WhatsApp. "
        "Máximo ~1.200 caracteres por respuesta; ofrece ampliar."
        if CANAL == "whatsapp" else ""
    )
    return [
        {"type": "text", "text": prompt + canal},
        {"type": "text", "text": "\n\n".join(docs), "cache_control": {"type": "ephemeral"}},
    ]


CLIENTE = anthropic.Anthropic()
SISTEMA = cargar_sistema()


def responder(historial: list, mensaje: str) -> str:
    historial.append({"role": "user", "content": mensaje})
    r = CLIENTE.messages.create(
        model=MODELO,
        max_tokens=1200,
        temperature=0.2,
        system=SISTEMA,
        messages=historial[-20:],   # últimas 10 interacciones
    )
    texto = "".join(b.text for b in r.content if b.type == "text")
    historial.append({"role": "assistant", "content": texto})
    return texto


if __name__ == "__main__":
    print(f"SonIA ({MODELO}, canal {CANAL}). Escribe 'salir' para terminar.\n")
    hist = []
    while True:
        try:
            msg = input("Tú: ").strip()
        except (EOFError, KeyboardInterrupt):
            break
        if msg.lower() in {"salir", "exit"}:
            break
        if msg:
            print(f"\nSonIA: {responder(hist, msg)}\n")
