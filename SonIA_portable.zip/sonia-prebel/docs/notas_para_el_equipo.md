# Notas para el equipo SonIA

## Cambios hechos al convertir el proyecto (2026-11-21)

1. **Aviso de IA neutral.** El original decía "funciona con inteligencia artificial (ChatGPT)".
   Se quitó "(ChatGPT)" para que sirva en cualquier plataforma. Si se quiere nombrar el modelo,
   agregarlo en `agent.yaml` → `mensajes_fijos.aviso_ia` y en el prompt.
2. **Cuarto archivo incluido.** Las instrucciones originales mencionaban 3 archivos; el proyecto
   tiene 4. Se incorporó el **Glosario Business Partner** como fuente y como 4.ª opción del menú.
3. **Reglas nuevas** (no estaban explícitas): preguntar el público cuando el trámite depende de
   él; no pedir datos personales en el chat; no convertir SMLMV a pesos; no aprobar créditos;
   presentar ambos datos cuando dos fuentes difieren; formato especial para WhatsApp.
4. **Limpieza de formato sin tocar el texto:** la tabla de cesantías venía partida entre páginas
   (HTML roto) y se pasó a subsecciones 2.1–2.6; casillas `[ ]` → viñetas; encabezados por tema.
5. **Enlaces:** se quitaron solo los parámetros de rastreo (`?_gl=...`) de los enlaces de Comfama
   y SuAporte. Verificar que abran correctamente.
6. **Ejemplo 3 (créditos):** se ajustó al nombre exacto de los créditos del corpus.

## Puntos para validar con Gestión Humana

| # | Hallazgo | Dónde |
|---|---|---|
| 1 | Plazo de entrega de incapacidades: **5 días hábiles** (Vinculación §8) vs **3 días hábiles** (Auxilio de incapacidad §2). ¿Son plazos distintos o hay que unificar? | 01 §8 · 03 §2 |
| 2 | Canal de incapacidades impulso y mercadeo: Vinculación da correo de Lucía **o** WhatsApp; Auxilios separa PI (WhatsApp) y PP (correo de Lucía). ¿Qué significan PA/PO/PI/PP? | 01 §8 · 03 §2 |
| 3 | El crédito de educación dice "no aplica para familiares"; el de vivienda dice que apoya a "empleados y sus familias". Confirmar alcance. | 02 §1 · §4 |
| 4 | Antigüedad: §5 dice 6 meses para **todos** los créditos, pero calamidad habitacional dice que **no** requiere antigüedad. | 02 §4 · §5 |
| 5 | Business Partners sin teléfono ni correo en el corpus. | 04 |
| 6 | El archivo de Vinculación salta de §9 a §11 (no hay §10). ¿Falta contenido? | 01 |
| 7 | Valores en pesos de auxilios: confirmar si son de 2026 y quién los actualiza cada año. | 03 |
| 8 | Contacto de cesantías (Lucía Mejía) aparece como "lucia.mejias"; confirmar el correo. | 01 §2 |

## Mantenimiento

- Responsable de contenido: Gestión Humana (Bienestar / Nómina).
- Responsable técnico: equipo SonIA / Ingeniería de Automatización (Alexander Londoño Pineda).
- Ciclo: documento nuevo → reemplazar en `knowledge/` → actualizar versión en `_catalogo.md` y
  `agent.yaml` → `/probar-sonia` → `python scripts/build.py` → publicar en la plataforma.
