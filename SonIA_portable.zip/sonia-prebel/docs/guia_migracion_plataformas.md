# Guía de migración de SonIA por plataforma

Regla general: **todas las plataformas usan los mismos dos insumos**
1. `prompts/system_prompt.md` → instrucciones de sistema
2. `knowledge/*.md` → base de conocimiento

Primero corre `python scripts/build.py` para generar `dist/`.

| Plataforma | Qué subir | Dónde |
|---|---|---|
| **Claude Code** | La carpeta completa | Abrir la carpeta con `claude`. Lee `CLAUDE.md` solo. Probar con el subagente `sonia` o `/probar-sonia` |
| **Claude.ai – Proyecto** | `prompts/system_prompt.md` como instrucciones; los 4 `.md` + `_catalogo.md` como conocimiento | Proyecto → Instrucciones / Archivos |
| **Claude.ai – Skill** | `dist/sonia-gestion-humana.zip` | Configuración → Capacidades → Skills → Subir |
| **API de Claude** | `scripts/chat_api.py` (ya carga todo con caché de prompt) | Servidor de Prebel |
| **ChatGPT – GPT personalizado** | Instrucciones: `dist/gpt_instrucciones.md` (el campo tiene límite de 8.000 caracteres). Conocimiento: `system_prompt.md` + los 4 `.md` + `_catalogo.md`. Desactivar navegación web | Crear GPT → Configurar |
| **OpenAI API / Assistants** | `system` = `dist/sonia_prompt_completo.md` | Igual que la API de Claude |
| **Gemini (Gem) / Google AI Studio** | Instrucciones = `system_prompt.md`; archivos = `knowledge/` | Gem → Instrucciones + Conocimiento |
| **Microsoft Copilot Studio** | Instrucciones = `system_prompt.md`; Conocimiento = cargar los `.md` (o SharePoint). Desactivar "conocimiento general" y búsqueda web | Agente → Descripción general / Conocimiento |
| **n8n / Make / Dialogflow CX / Botpress** | Nodo LLM con `system` = `dist/sonia_prompt_completo.md` | Nodo de IA |
| **Cursor / Codex / Copilot (código)** | Leen `AGENTS.md` | Raíz del repo |

## Ruta recomendada hacia WhatsApp (on-premise)

```
Colaborador ──WhatsApp──▶ Meta WhatsApp Cloud API ──webhook HTTPS──▶ Servidor Prebel
                                                                     │  (FastAPI/Flask)
                                                                     │  responder(historial, msg)
                                                                     ▼
                                                               API del modelo (Claude u otro)
                                                               system = prompt + knowledge
```

Pasos:

1. **Meta:** cuenta de Meta Business verificada, app en developers.facebook.com con el producto
   WhatsApp, número de Prebel registrado (no puede estar activo en la app normal de WhatsApp),
   token permanente de usuario del sistema y plantilla aprobada si SonIA inicia conversaciones.
2. **Servidor:** endpoint HTTPS público (certificado válido) que:
   - responde al `GET` de verificación del webhook (`hub.verify_token`, `hub.challenge`);
   - recibe el `POST` de mensajes, guarda el historial por número (máx. 10 turnos);
   - llama a `responder()` de `scripts/chat_api.py` con `SONIA_CANAL=whatsapp`;
   - envía la respuesta con `POST /{phone-number-id}/messages`.
3. **Seguridad:** llaves en variables de entorno o bóveda; validar la firma `X-Hub-Signature-256`;
   definir con Prebel la política de retención de conversaciones.
4. **Prueba:** correr `evals/casos_prueba.yaml` contra el endpoint antes de abrirlo a usuarios.

> Los requisitos exactos de Meta (verificación, costos por conversación, plantillas) cambian;
> confírmenlos en la documentación oficial de WhatsApp Business Platform al momento de conectar.

## Por qué "contexto completo" y no RAG

El corpus pesa ~80 KB (~22 mil tokens con el prompt). Cabe completo en el contexto de cualquier modelo actual.
Así el modelo ve todas las secciones a la vez (evita respuestas incompletas cuando un dato está
repartido) y, con caché de prompt, el costo por mensaje baja. Pasar a RAG solo si el corpus crece
a cientos de páginas.
